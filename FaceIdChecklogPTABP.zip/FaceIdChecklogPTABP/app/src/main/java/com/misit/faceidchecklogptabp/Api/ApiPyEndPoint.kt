package com.misit.faceidchecklogptabp.Api

import retrofit2.http.GET
import retrofit2.http.Query

class ApiPyEndPoint {
//    @GET("/")
//    fun getToken(@Query("nik") nik:String): Call<CsrfTokenResponse>?
}