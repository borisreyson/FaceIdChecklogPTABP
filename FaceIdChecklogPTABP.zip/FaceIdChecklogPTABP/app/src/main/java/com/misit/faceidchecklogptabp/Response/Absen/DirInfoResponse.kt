package com.misit.faceidchecklogptabp.Response.Absen

data class DirInfoResponse(
	val folder: Boolean? = null
)
