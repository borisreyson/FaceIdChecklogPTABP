package com.misit.faceidchecklogptabp.Response

import com.google.gson.annotations.SerializedName

data class ListAbsenResponse(

	@field:SerializedName("listAbsen")
	val listAbsen: ListAbsen? = null
)